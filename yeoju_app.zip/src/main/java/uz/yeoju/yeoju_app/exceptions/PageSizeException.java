package uz.yeoju.yeoju_app.exceptions;

public class PageSizeException extends Exception{
    public PageSizeException(String message) {
        super(message);
    }
}
