package uz.yeoju.yeoju_app.service.serviceInterfaces.implService;

import uz.yeoju.yeoju_app.service.serviceInterfaces.MainService;

public interface EduLanImplService<T> extends MainService<T> {
}
