package uz.yeoju.yeoju_app.service.serviceInterfaces.implService;

import uz.yeoju.yeoju_app.service.serviceInterfaces.MainLongService;

public interface GanderImplService<T> extends MainLongService<T> {
}
