package uz.yeoju.yeoju_app.service.serviceInterfaces.implService;

import uz.yeoju.yeoju_app.service.serviceInterfaces.MainLongService;

public interface RetakeImplService<T> extends MainLongService<T> {
}
