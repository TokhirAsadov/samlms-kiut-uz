package uz.yeoju.yeoju_app.service.serviceInterfaces.implService.roleAndPositionGroup;

import uz.yeoju.yeoju_app.payload.ApiResponse;

public interface RoleAndPositionGroupService {

    ApiResponse findAll();

}
