package uz.yeoju.yeoju_app.service.serviceInterfaces.implService;

import uz.yeoju.yeoju_app.service.serviceInterfaces.MainLongService;

public interface PositionImplService<T> extends MainLongService<T> {
}
