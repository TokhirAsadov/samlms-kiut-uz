package uz.yeoju.yeoju_app.service.serviceInterfaces.implService;

import uz.yeoju.yeoju_app.service.serviceInterfaces.MainService;

public interface SmsLogImplService<T> extends MainService<T> {
}
