package uz.yeoju.yeoju_app.entity.attachment;

public enum PhotoType {

    AVATAR

}
