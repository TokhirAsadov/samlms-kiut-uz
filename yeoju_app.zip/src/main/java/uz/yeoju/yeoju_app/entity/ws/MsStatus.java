package uz.yeoju.yeoju_app.entity.ws;

public enum MsStatus {
    JOIN,
    MESSAGE,
    LEAVE
}
