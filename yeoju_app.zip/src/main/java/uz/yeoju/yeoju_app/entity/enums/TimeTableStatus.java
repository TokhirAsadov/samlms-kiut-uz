package uz.yeoju.yeoju_app.entity.enums;

public enum TimeTableStatus {
    FIRST_HALF_YEAR,
    SECOND_HALF_YEAR
}
