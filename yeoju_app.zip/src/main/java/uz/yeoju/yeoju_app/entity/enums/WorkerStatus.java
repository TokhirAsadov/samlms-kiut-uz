package uz.yeoju.yeoju_app.entity.enums;

public enum WorkerStatus {
    ASOSIY,
    ORINDOSH,
    SOATBAY,

}
