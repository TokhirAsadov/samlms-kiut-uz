package uz.yeoju.yeoju_app.entity.enums;

public enum PhoneType {
    MOBILE_PHONE,
    FATHER_PHONE,
    MOTHER_PHONE,
    HOME_PHONE,
    WORK_PHONE,
    OTHER_PHONE
}
