package uz.yeoju.yeoju_app.entity.enums;

public enum SmsType {
    ALL,
    COURSE,
    GROUP,
    STUDENT,
    TEACHER,
    ALL_TEACHER
}
