package uz.yeoju.yeoju_app.entity.enums;

public enum TeachStatus {
    TEACHING,
    FINISHED,
    ACADEMIC_VACATION,
    EXPELLED_FROM_UNIVERSITY
}
