package uz.yeoju.yeoju_app.entity.enums;

public enum Gandername {
    MALE,
    FEMALE
}
