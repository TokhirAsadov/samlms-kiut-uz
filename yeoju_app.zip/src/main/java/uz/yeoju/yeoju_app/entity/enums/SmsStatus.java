package uz.yeoju.yeoju_app.entity.enums;

public enum SmsStatus {
    SENDING,
    SEND,
    FAILED,
    WARNING
}
