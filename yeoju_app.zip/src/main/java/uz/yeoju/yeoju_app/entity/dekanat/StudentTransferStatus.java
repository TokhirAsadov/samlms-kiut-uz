package uz.yeoju.yeoju_app.entity.dekanat;

public enum StudentTransferStatus {
    DURING,
    REJECT,
    CONFIRM
}
