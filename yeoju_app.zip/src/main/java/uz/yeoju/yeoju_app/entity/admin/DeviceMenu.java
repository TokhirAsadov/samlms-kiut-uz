package uz.yeoju.yeoju_app.entity.admin;

import java.util.Date;

public interface DeviceMenu {
    String getId();
    String getFullName();
    String getDevice();
    String getRoom();
    Date getTime();
    String getPassword();
    String getCard();
    String getLogin();
}
