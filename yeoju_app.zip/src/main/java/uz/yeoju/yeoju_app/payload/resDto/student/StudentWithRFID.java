package uz.yeoju.yeoju_app.payload.resDto.student;

public interface StudentWithRFID {
    String getFullName();
    String getRFID();
}
