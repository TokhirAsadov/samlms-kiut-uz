package uz.yeoju.yeoju_app.payload.resDto.section;

public interface SectionData {
    String getId();

    String getName();


}
