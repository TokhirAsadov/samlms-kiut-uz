package uz.yeoju.yeoju_app.payload.admin;

public class MachinesDto {
}
