package uz.yeoju.yeoju_app.payload.resDto.group;

public interface GroupForStudent {
    String getId();
    String getName();
}
