package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface GroupByFacultyIdAndCourse {
    String getValue();
    String getLabel();
}
