package uz.yeoju.yeoju_app.payload.resDto.user;

public interface GetUsersByRoleNameAndBetweenDate {
    String getFullName();
    String getCountOfTouch();
    String getCardNumber();
}
