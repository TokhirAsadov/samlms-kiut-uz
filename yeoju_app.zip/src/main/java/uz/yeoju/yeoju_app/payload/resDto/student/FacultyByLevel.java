package uz.yeoju.yeoju_app.payload.resDto.student;

public interface FacultyByLevel {
    String getName();
    Integer getLevel();
}
