package uz.yeoju.yeoju_app.payload.resDto.kafedra;

public interface ComeCountTodayStatistics {
    String getKafedraId();
    Integer getAllCount();
    Integer getComeCount();
}
