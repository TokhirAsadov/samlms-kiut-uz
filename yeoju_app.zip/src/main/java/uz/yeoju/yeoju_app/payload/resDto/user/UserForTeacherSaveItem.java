package uz.yeoju.yeoju_app.payload.resDto.user;

public interface UserForTeacherSaveItem {
    String getValue();
    String getLabel();
}
