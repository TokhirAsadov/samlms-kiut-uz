package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface StudentGroupField {
    String getId();
    Integer getLevel();
    String getName();
    String getFacultyName();
    String getEducationTypeName();
}
