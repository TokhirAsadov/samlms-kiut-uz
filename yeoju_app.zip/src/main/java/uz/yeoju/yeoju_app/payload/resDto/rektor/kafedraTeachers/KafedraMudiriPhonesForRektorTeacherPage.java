package uz.yeoju.yeoju_app.payload.resDto.rektor.kafedraTeachers;

public interface KafedraMudiriPhonesForRektorTeacherPage {
    String getId();
    String getPhoneType();
    String getPhoneNumber();
}
