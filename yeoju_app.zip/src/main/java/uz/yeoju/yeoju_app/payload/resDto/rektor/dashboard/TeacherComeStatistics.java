package uz.yeoju.yeoju_app.payload.resDto.rektor.dashboard;

public interface TeacherComeStatistics {
    Integer getAllCount();
    Integer getComeCount();
}
