package uz.yeoju.yeoju_app.payload.resDto.rektor.dashboard;

public interface StudentEduLangFormType {
    Integer getCount();
    String getName();
}
