package uz.yeoju.yeoju_app.payload.resDto.rektor.dashboard;

public interface StaffCountComeAndAll {
    String getId();
    Integer getComeCount();
    Integer getAllCount();
}
