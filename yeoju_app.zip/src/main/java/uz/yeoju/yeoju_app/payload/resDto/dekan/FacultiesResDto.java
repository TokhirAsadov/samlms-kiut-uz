package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface FacultiesResDto {
    String getValue();
    String getLabel();
}
