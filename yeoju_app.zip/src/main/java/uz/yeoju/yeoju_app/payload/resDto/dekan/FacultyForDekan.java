package uz.yeoju.yeoju_app.payload.resDto.dekan;

import org.springframework.beans.factory.annotation.Value;

import java.util.List;

public interface FacultyForDekan {

    String getId();
    String getName();

}
