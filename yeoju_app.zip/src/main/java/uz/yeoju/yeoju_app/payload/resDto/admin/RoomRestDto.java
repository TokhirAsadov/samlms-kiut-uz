package uz.yeoju.yeoju_app.payload.resDto.admin;

public interface RoomRestDto {
    String getId();
    String getName();
}
