package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface StudentAddress {
    String getId();
    String getCountry();
    String getRegion();
    String getArea();
    String getAddress();

    boolean getConstant();
    boolean getIsCurrent();
}
