package uz.yeoju.yeoju_app.payload.resDto.admin;

public interface BuildingRestDto {
    String getId();
    String getName();
}
