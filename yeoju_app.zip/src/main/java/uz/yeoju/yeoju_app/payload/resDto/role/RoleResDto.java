package uz.yeoju.yeoju_app.payload.resDto.role;

public interface RoleResDto {
    String getId();
    String getRoleName();
}
