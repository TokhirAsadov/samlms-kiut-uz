package uz.yeoju.yeoju_app.payload.kafedra;

import lombok.Data;

@Data
public class KafedraMudiriSaving {
    private String userId;
    private String kafedraId;
}
