package uz.yeoju.yeoju_app.payload.resDto.chat;

public interface ChatsRes {
}
