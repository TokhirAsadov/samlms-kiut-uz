package uz.yeoju.yeoju_app.payload.resDto.admin;

public interface MachinesRestDto {
    Long getId();
    String getIp();
}
