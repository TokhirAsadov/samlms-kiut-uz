package uz.yeoju.yeoju_app.payload.resDto.student;

public interface FacultyStatistic {
    String getName();
    Integer getComeCount();
    Integer getAllCount();
}
