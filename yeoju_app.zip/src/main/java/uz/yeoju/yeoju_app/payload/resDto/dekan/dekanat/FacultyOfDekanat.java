package uz.yeoju.yeoju_app.payload.resDto.dekan.dekanat;

public interface FacultyOfDekanat {
    String getId();
    String getName();
    String getShortName();
}
