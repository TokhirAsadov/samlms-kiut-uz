package uz.yeoju.yeoju_app.payload.resDto.kafedra.month;

import java.util.Date;

public interface GetEnterOutTimes {
    String getCardNo();
    Date getTimeAsc();
    Date getTimeDesc();
    Date getTime();
}
