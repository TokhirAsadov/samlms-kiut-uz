package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface FailsCountOfGroup {
    String getName();
    Integer getCount();
}
