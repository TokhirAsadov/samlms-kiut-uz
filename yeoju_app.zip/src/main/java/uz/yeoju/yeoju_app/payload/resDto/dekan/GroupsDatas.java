package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface GroupsDatas {
    String getId();
    Integer getLevel();
    String getName();
    String getLanguage();
    String getType();
    String getForm();
    String getFaculty();
}
