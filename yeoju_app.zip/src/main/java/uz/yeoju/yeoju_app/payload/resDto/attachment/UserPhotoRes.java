package uz.yeoju.yeoju_app.payload.resDto.attachment;

public interface UserPhotoRes {
    String getId();
    String getOriginalName();
    Long getSize();
    String getContentType();
}
