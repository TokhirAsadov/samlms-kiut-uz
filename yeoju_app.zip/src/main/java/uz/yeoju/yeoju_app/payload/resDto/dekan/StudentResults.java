package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface StudentResults {
    Long getId();
    String getYear();
    Integer getSemester();
    String getSubject();
    Integer getCredit();
    Integer getScore();
}
