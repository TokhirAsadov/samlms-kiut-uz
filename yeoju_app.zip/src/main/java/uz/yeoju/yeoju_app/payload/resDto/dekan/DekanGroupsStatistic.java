package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface DekanGroupsStatistic {
    String getLevel();
    String getName();
    String getComeCount();
    String getAllCount();
}
