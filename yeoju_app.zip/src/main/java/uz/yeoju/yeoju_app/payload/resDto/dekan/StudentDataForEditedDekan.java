package uz.yeoju.yeoju_app.payload.resDto.dekan;

import java.util.Date;

public interface StudentDataForEditedDekan {

    String getId();
    String getLogin();
    String getFullName();
    String getCitizenship();
    String getNationality();
    String getPassportNum();
    String getEmail();
    String getRFID();
    String getGroupName();
    Integer getLevel();

}
