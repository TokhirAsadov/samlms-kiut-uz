package uz.yeoju.yeoju_app.payload.resDto.admin;

public interface DeviceList {
    Long getId();
    String getIp();
    Integer getPort();
    String getRoom();
}
