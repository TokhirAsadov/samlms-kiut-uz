package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface StudentPhones {
    String getId();
    String getPhoneNumber();
    String getPhoneType();

    Boolean getHasTg();
    Boolean getHasInstagram();
    Boolean getHasFacebook();
}
