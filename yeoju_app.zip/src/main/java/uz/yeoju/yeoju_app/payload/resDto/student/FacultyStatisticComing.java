package uz.yeoju.yeoju_app.payload.resDto.student;

public interface FacultyStatisticComing {
    String getName();
    Integer getComeCount();
}
