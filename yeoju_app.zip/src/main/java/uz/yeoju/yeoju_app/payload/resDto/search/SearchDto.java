package uz.yeoju.yeoju_app.payload.resDto.search;

public interface SearchDto {
    String getUserId();
    String getFullName();
    String getLogin();
    String getPassport();
    String getRoleName();
}
