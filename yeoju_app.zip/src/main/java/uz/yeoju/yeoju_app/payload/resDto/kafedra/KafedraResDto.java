package uz.yeoju.yeoju_app.payload.resDto.kafedra;

public interface KafedraResDto {
    String getId();
    String getName();
}
