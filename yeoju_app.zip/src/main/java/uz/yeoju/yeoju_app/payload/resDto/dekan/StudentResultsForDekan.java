package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface StudentResultsForDekan {
    String getId();
    Integer getFail();
    String getFullName();
    String getEmail();
    String getPassport();
    String getLogin();
    String getCardNo();
}
