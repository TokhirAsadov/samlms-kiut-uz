package uz.yeoju.yeoju_app.payload.resDto.student;

public interface FacultyStatisticAll {
    String getName();
    Integer getAllCount();
}
