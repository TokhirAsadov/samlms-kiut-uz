package uz.yeoju.yeoju_app.payload.resDto.dekan;

public interface CourseStatistics {
    Integer getLevel();
    String getComeCount();
    String getAllCount();
}
